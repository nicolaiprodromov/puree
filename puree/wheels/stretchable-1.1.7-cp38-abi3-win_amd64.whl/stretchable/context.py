from .core import Taffy

taffy = Taffy()
