class TaffyUnavailableError(Exception):
    ...


class NodeLocatorError(Exception):
    ...


class NodeNotFound(Exception):
    ...


class LayoutNotComputedError(Exception):
    ...
