from textual.widgets._collapsible import CollapsibleTitle

__all__ = ["CollapsibleTitle"]
