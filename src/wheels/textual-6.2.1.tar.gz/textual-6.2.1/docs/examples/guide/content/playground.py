from textual._markup_playground import MarkupPlayground

if __name__ == "__main__":
    app = MarkupPlayground()
    app.run()
